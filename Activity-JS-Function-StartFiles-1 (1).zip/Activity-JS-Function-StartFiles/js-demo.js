﻿/*
   JS Activity Clock
   Name: 
   Date:   

   function getWeekday(dayNum)
      Returns the text of the day of the week where dayNum
      is the number of the week from 0 (Sunday) to 6 (Saturday)
*/
